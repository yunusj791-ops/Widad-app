package com.example.data

import com.example.R
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

class WidadRepository {

    // Current App Language
    private val _appLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

    // Current User
    private val _currentUser = MutableStateFlow(
        UserProfile(
            id = "user_me",
            displayName = "Tariq Al-Mansoor",
            birthDate = "1996-05-14",
            calculatedAge = 29,
            country = "United Arab Emirates",
            city = "Dubai",
            languages = listOf("Arabic", "English"),
            bio = "Architect and urban designer passionate about sustainable Islamic heritage. Seeking a partner who values mutual kindness, shared intellectual curiosity, and building an enduring family together.",
            interests = listOf("Architecture", "Literature", "Travel", "Arabic Calligraphy", "Equestrian", "Nature"),
            relationshipGoal = RelationshipGoal.MARRIAGE_SOON,
            religiousPractice = ReligiousPractice.MODERATELY_PRACTICING,
            profession = "Senior Architect",
            education = "Master of Architecture",
            photoResId = R.drawable.img_avatar_tariq,
            isVerified = true,
            isPremium = false
        )
    )
    val currentUser: StateFlow<UserProfile> = _currentUser.asStateFlow()

    // Discovery Profiles
    private val _profiles = MutableStateFlow<List<UserProfile>>(emptyList())
    val profiles: StateFlow<List<UserProfile>> = _profiles.asStateFlow()

    // Matches
    private val _matches = MutableStateFlow<List<MatchRecord>>(emptyList())
    val matches: StateFlow<List<MatchRecord>> = _matches.asStateFlow()

    // Messages per conversation
    private val _messages = MutableStateFlow<Map<String, List<ChatMessage>>>(emptyMap())
    val messages: StateFlow<Map<String, List<ChatMessage>>> = _messages.asStateFlow()

    // Likes sent by current user
    private val _likedUserIds = MutableStateFlow<Set<String>>(emptySet())
    val likedUserIds: StateFlow<Set<String>> = _likedUserIds.asStateFlow()

    // Passed user ids
    private val _passedUserIds = MutableStateFlow<Set<String>>(emptySet())
    val passedUserIds: StateFlow<Set<String>> = _passedUserIds.asStateFlow()

    // Blocked user ids
    private val _blockedUserIds = MutableStateFlow<Set<String>>(emptySet())
    val blockedUserIds: StateFlow<Set<String>> = _blockedUserIds.asStateFlow()

    // Safety Reports
    private val _safetyReports = MutableStateFlow<List<SafetyReport>>(emptyList())
    val safetyReports: StateFlow<List<SafetyReport>> = _safetyReports.asStateFlow()

    // Payments / Subscriptions
    private val _payments = MutableStateFlow<List<PaystackPayment>>(emptyList())
    val payments: StateFlow<List<PaystackPayment>> = _payments.asStateFlow()

    // Notifications
    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    // Membership Plans
    val membershipPlans = listOf(
        MembershipPlan(
            id = "plan_free",
            nameEn = "Standard Free",
            nameAr = "الباقة المجانية",
            priceUsd = 0.0,
            interval = PlanInterval.MONTHLY,
            featuresEn = listOf(
                "Create complete verified profile",
                "Up to 10 daily intentional likes",
                "Mutual match notification",
                "Unlimited direct messaging with matches",
                "Basic country & age filters",
                "Standard safety controls"
            ),
            featuresAr = listOf(
                "إنشاء ملف تعريفي كامل وموثق",
                "١٠ إعجابات يومية هادفة",
                "إشعار فوري عند التوافق المتبادل",
                "محادثات غير محدودة مع المتوافقين",
                "فلاتر أساسية حسب الدولة والسن",
                "أدوات الأمان والحظر والتبليغ"
            )
        ),
        MembershipPlan(
            id = "plan_monthly",
            nameEn = "Premium Monthly",
            nameAr = "الاشتراك الشهري",
            priceUsd = 9.99,
            interval = PlanInterval.MONTHLY,
            featuresEn = listOf(
                "Unlimited daily likes",
                "See who liked you before matching",
                "Advanced cultural & values filters",
                "Read receipts for all conversations",
                "Priority profile discovery boost",
                "Incognito & discreet profile mode"
            ),
            featuresAr = listOf(
                "إعجابات يومية غير محدودة",
                "معرفة من أُعجب بملفك قبل التوافق",
                "فلاتر متقدمة للقيم واللغات والالتزام",
                "مؤشرات قراءة الرسائل في المحادثات",
                "أولوية الظهور في نتائج الاستكشاف",
                "وضع الخصوصية والتصفح الخفي"
            ),
            isPopular = false
        ),
        MembershipPlan(
            id = "plan_quarterly",
            nameEn = "Quarterly Courting",
            nameAr = "باقة ٣ أشهر المميزة",
            priceUsd = 24.99,
            interval = PlanInterval.QUARTERLY,
            featuresEn = listOf(
                "Everything in Premium Monthly",
                "Save 17% compared to monthly",
                "Complimentary 3 profile spotlights",
                "Direct relationship advisor guidelines",
                "Priority safety verification badge"
            ),
            featuresAr = listOf(
                "جميع مزايا الباقة الشهرية",
                "توفير ١٧٪ مقارنة بالدفع الشهري",
                "٣ إبرازات مميزة لملفك مجاناً",
                "إرشادات التوفيق والتعارف الجاد",
                "شارة الأولوية والتحقق الموثق"
            ),
            isPopular = true
        ),
        MembershipPlan(
            id = "plan_annual",
            nameEn = "Annual Commitment",
            nameAr = "الباقة السنوية الكاملة",
            priceUsd = 79.99,
            interval = PlanInterval.ANNUAL,
            featuresEn = listOf(
                "Complete full-year access (33% off)",
                "Full VIP discovery features",
                "Unlimited rewinds on passed profiles",
                "Exclusive verified circle badge",
                "Dedicated email concierge support"
            ),
            featuresAr = listOf(
                "اشتراك سنوي كامل (خصم ٣٣٪)",
                "كافة ميزات الاستكشاف المتقدمة",
                "التراجع غير المحدود عن التخطي",
                "شارة الدائرة الموثقة الحصرية",
                "دعم استشاري مخصص عبر البريد"
            ),
            isPopular = false
        )
    )

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val initialProfiles = listOf(
            UserProfile(
                id = "user_layla",
                displayName = "Layla Al-Hashimi",
                birthDate = "1997-09-22",
                calculatedAge = 28,
                country = "United Arab Emirates",
                city = "Abu Dhabi",
                languages = listOf("Arabic", "English", "French"),
                bio = "Literature educator and researcher with a deep love for Andalusian poetry, specialty coffee, and meaningful dialogue. Looking for an educated, grounded partner with shared family values.",
                interests = listOf("Literature", "Coffee Brewing", "Arts", "Travel", "Nature", "Calligraphy"),
                relationshipGoal = RelationshipGoal.MARRIAGE_SOON,
                religiousPractice = ReligiousPractice.MODERATELY_PRACTICING,
                profession = "University Lecturer",
                education = "Ph.D. in Comparative Literature",
                photoResId = R.drawable.img_avatar_layla,
                isVerified = true,
                isPremium = true
            ),
            UserProfile(
                id = "user_noor",
                displayName = "Noor El-Sayed",
                birthDate = "1998-03-12",
                calculatedAge = 27,
                country = "Egypt",
                city = "Cairo",
                languages = listOf("Arabic", "English"),
                bio = "Biomedical engineer dedicated to healthcare technology. I cherish family gatherings, weekend hiking trips, and quiet evenings with classic books. Honest communication is paramount.",
                interests = listOf("Health & Wellness", "Hiking", "Literature", "Volunteering", "Cooking"),
                relationshipGoal = RelationshipGoal.MARRIAGE_FOCUSED,
                religiousPractice = ReligiousPractice.MODERATELY_PRACTICING,
                profession = "Biomedical Engineer",
                education = "B.Sc. Biomedical Engineering",
                photoResId = R.drawable.img_avatar_layla,
                isVerified = true,
                isPremium = false
            ),
            UserProfile(
                id = "user_omar",
                displayName = "Omar Haddad",
                birthDate = "1994-11-04",
                calculatedAge = 31,
                country = "Jordan",
                city = "Amman",
                languages = listOf("Arabic", "English"),
                bio = "Software architect and entrepreneur. Passionate about innovation, equestrian traditions, and history. Ready to build a loving and resilient household rooted in respect.",
                interests = listOf("Entrepreneurship", "Equestrian", "History", "Astronomy", "Travel"),
                relationshipGoal = RelationshipGoal.MARRIAGE_SOON,
                religiousPractice = ReligiousPractice.VERY_PRACTICING,
                profession = "Software Architect",
                education = "M.Sc. Computer Science",
                photoResId = R.drawable.img_avatar_tariq,
                isVerified = true,
                isPremium = true
            ),
            UserProfile(
                id = "user_farida",
                displayName = "Farida Benali",
                birthDate = "1996-07-19",
                calculatedAge = 29,
                country = "Morocco",
                city = "Rabat",
                languages = listOf("Arabic", "French", "English"),
                bio = "Financial analyst with a passion for Moroccan artisanal design and culinary arts. Seeking a warm-hearted companion who believes in teamwork and mutual emotional support.",
                interests = listOf("Gastronomy", "Design", "Economics", "Travel", "Museums"),
                relationshipGoal = RelationshipGoal.SERIOUS_RELATIONSHIP,
                religiousPractice = ReligiousPractice.MODERATELY_PRACTICING,
                profession = "Senior Financial Analyst",
                education = "Master of Finance",
                photoResId = R.drawable.img_avatar_layla,
                isVerified = true,
                isPremium = false
            ),
            UserProfile(
                id = "user_zayd",
                displayName = "Zayd Al-Khatib",
                birthDate = "1993-01-28",
                calculatedAge = 32,
                country = "Saudi Arabia",
                city = "Riyadh",
                languages = listOf("Arabic", "English"),
                bio = "Environmental consultant and avid desert photographer. Seeking a life partner who embraces kindness, deep faith, and enthusiasm for personal growth.",
                interests = listOf("Photography", "Nature", "Astronomy", "Volunteering", "Literature"),
                relationshipGoal = RelationshipGoal.MARRIAGE_FOCUSED,
                religiousPractice = ReligiousPractice.VERY_PRACTICING,
                profession = "Environmental Consultant",
                education = "M.Sc. Environmental Science",
                photoResId = R.drawable.img_avatar_tariq,
                isVerified = true,
                isPremium = true
            )
        )
        _profiles.value = initialProfiles

        // Seed 1 existing match with Layla so chat is instantly testable out of the box!
        val matchId = "match_me_layla"
        val existingMatch = MatchRecord(
            id = matchId,
            user1Id = "user_me",
            user2Id = "user_layla",
            matchedAtTimestamp = System.currentTimeMillis() - 86400000,
            lastMessage = "Assalamu Alaikum Tariq! Thank you for the thoughtful message.",
            lastMessageTime = "Yesterday",
            unreadCount = 1
        )
        _matches.value = listOf(existingMatch)
        _likedUserIds.value = setOf("user_layla")

        _messages.value = mapOf(
            matchId to listOf(
                ChatMessage(
                    id = "msg_1",
                    conversationId = matchId,
                    senderId = "user_me",
                    recipientId = "user_layla",
                    text = "Peace be upon you Layla. I was genuinely impressed by your academic research on Andalusian poetry.",
                    timeFormatted = "Yesterday 16:30",
                    isRead = true
                ),
                ChatMessage(
                    id = "msg_2",
                    conversationId = matchId,
                    senderId = "user_layla",
                    recipientId = "user_me",
                    text = "Assalamu Alaikum Tariq! Thank you for the thoughtful message. It is wonderful to meet an architect who appreciates classical heritage.",
                    timeFormatted = "Yesterday 18:45",
                    isRead = true
                )
            )
        )

        // Initial notifications
        _notifications.value = listOf(
            AppNotification(
                id = "notif_1",
                title = "Mutual Match Celebrated! مودة ومحبة",
                message = "You and Layla Al-Hashimi both expressed interest in each other.",
                timestampFormatted = "Yesterday",
                isRead = true,
                type = "MATCH"
            ),
            AppNotification(
                id = "notif_2",
                title = "Welcome to Widad (مودة)",
                message = "Your profile is active. Remember: initial safety and respectful communication lead to blessed partnerships.",
                timestampFormatted = "2 days ago",
                isRead = true,
                type = "SAFETY"
            )
        )

        // Seed sample safety reports for admin queue demo
        _safetyReports.value = listOf(
            SafetyReport(
                id = "rep_101",
                reporterId = "user_omar",
                reportedUserId = "user_suspicious_1",
                reportedUserName = "Crypto Investment Bot",
                reason = "Commercial / Financial solicitation",
                details = "User initiated conversation asking to invest in unauthorized trading scheme.",
                status = "OPEN"
            )
        )
    }

    fun setLanguage(language: AppLanguage) {
        _appLanguage.value = language
    }

    fun updateCurrentUser(profile: UserProfile) {
        _currentUser.value = profile
    }

    // Like a profile. If target is Layla or Noor, triggers immediate mutual match!
    fun likeProfile(targetUserId: String): Boolean {
        val currentLikes = _likedUserIds.value.toMutableSet()
        currentLikes.add(targetUserId)
        _likedUserIds.value = currentLikes

        // Check if mutual match occurs
        // Layla, Noor, and Omar will reciprocate likes
        val reciprocates = targetUserId in listOf("user_layla", "user_noor", "user_omar")
        if (reciprocates) {
            val matchId = "match_me_$targetUserId"
            val targetProfile = _profiles.value.find { it.id == targetUserId }
            val existing = _matches.value.find { it.id == matchId }
            if (existing == null) {
                val newMatch = MatchRecord(
                    id = matchId,
                    user1Id = _currentUser.value.id,
                    user2Id = targetUserId,
                    matchedAtTimestamp = System.currentTimeMillis(),
                    lastMessage = "You both connected! Start a respectful conversation.",
                    lastMessageTime = "Just now",
                    unreadCount = 1
                )
                _matches.value = _matches.value + newMatch

                // Add notification
                val notif = AppNotification(
                    id = "notif_${System.currentTimeMillis()}",
                    title = "New Mutual Match! توافق جديد",
                    message = "You and ${targetProfile?.displayName ?: "a member"} liked each other!",
                    timestampFormatted = "Just now",
                    isRead = false,
                    type = "MATCH"
                )
                _notifications.value = listOf(notif) + _notifications.value
            }
            return true
        }
        return false
    }

    fun passProfile(targetUserId: String) {
        val currentPasses = _passedUserIds.value.toMutableSet()
        currentPasses.add(targetUserId)
        _passedUserIds.value = currentPasses
    }

    fun sendMessage(conversationId: String, recipientId: String, text: String) {
        if (text.isBlank()) return
        val currentMsgMap = _messages.value.toMutableMap()
        val list = currentMsgMap[conversationId]?.toMutableList() ?: mutableListOf()

        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val newMsg = ChatMessage(
            id = "msg_${System.currentTimeMillis()}",
            conversationId = conversationId,
            senderId = _currentUser.value.id,
            recipientId = recipientId,
            text = text.trim(),
            timestamp = System.currentTimeMillis(),
            timeFormatted = timeFormat.format(Date()),
            isRead = true
        )
        list.add(newMsg)
        currentMsgMap[conversationId] = list
        _messages.value = currentMsgMap

        // Update match last message
        val updatedMatches = _matches.value.map { match ->
            if (match.id == conversationId) {
                match.copy(lastMessage = text.trim(), lastMessageTime = "Just now")
            } else match
        }
        _matches.value = updatedMatches
    }

    fun unmatch(conversationId: String, targetUserId: String) {
        _matches.value = _matches.value.filterNot { it.id == conversationId }
        val currentLikes = _likedUserIds.value.toMutableSet()
        currentLikes.remove(targetUserId)
        _likedUserIds.value = currentLikes
    }

    fun blockUser(targetUserId: String, reason: String = "User requested block") {
        val currentBlocked = _blockedUserIds.value.toMutableSet()
        currentBlocked.add(targetUserId)
        _blockedUserIds.value = currentBlocked

        // Remove from matches and profiles
        _matches.value = _matches.value.filterNot { it.user1Id == targetUserId || it.user2Id == targetUserId }
        _profiles.value = _profiles.value.filterNot { it.id == targetUserId }
    }

    fun reportUser(reportedUserId: String, reason: String, details: String) {
        val reportedProfile = _profiles.value.find { it.id == reportedUserId }
        val report = SafetyReport(
            id = "rep_${System.currentTimeMillis()}",
            reporterId = _currentUser.value.id,
            reportedUserId = reportedUserId,
            reportedUserName = reportedProfile?.displayName ?: "User $reportedUserId",
            reason = reason,
            details = details,
            status = "OPEN"
        )
        _safetyReports.value = listOf(report) + _safetyReports.value
    }

    // Process Paystack Payment Simulation & Verification
    fun processPaystackCheckout(plan: MembershipPlan, customerEmail: String, simulateSuccess: Boolean = true): PaystackPayment {
        val reference = "WIDAD-PAY-${System.currentTimeMillis()}"
        val payment = PaystackPayment(
            reference = reference,
            userId = _currentUser.value.id,
            planId = plan.id,
            amountUsd = plan.priceUsd,
            currency = "USD",
            status = if (simulateSuccess) "success" else "failed",
            customerEmail = customerEmail
        )

        _payments.value = listOf(payment) + _payments.value

        if (simulateSuccess) {
            _currentUser.value = _currentUser.value.copy(isPremium = true)
            val notif = AppNotification(
                id = "notif_${System.currentTimeMillis()}",
                title = "Premium Membership Activated! باقة التميز مفعلة",
                message = "Your subscription to ${plan.nameEn} is active. Enjoy unlimited intentional discovery.",
                timestampFormatted = "Just now",
                isRead = false,
                type = "BILLING"
            )
            _notifications.value = listOf(notif) + _notifications.value
        }

        return payment
    }

    fun cancelSubscription() {
        _currentUser.value = _currentUser.value.copy(isPremium = false)
        val notif = AppNotification(
            id = "notif_${System.currentTimeMillis()}",
            title = "Subscription Cancelled",
            message = "Your membership will remain standard until renewal period ends.",
            timestampFormatted = "Just now",
            isRead = false,
            type = "BILLING"
        )
        _notifications.value = listOf(notif) + _notifications.value
    }

    // Admin operations
    fun suspendUser(userId: String) {
        _profiles.value = _profiles.value.map {
            if (it.id == userId) it.copy(isSuspended = true) else it
        }
    }

    fun reinstateUser(userId: String) {
        _profiles.value = _profiles.value.map {
            if (it.id == userId) it.copy(isSuspended = false) else it
        }
    }

    fun resolveReport(reportId: String, status: String) {
        _safetyReports.value = _safetyReports.value.map {
            if (it.id == reportId) it.copy(status = status) else it
        }
    }

    // Compatibility Calculation Algorithm
    fun calculateCompatibility(userA: UserProfile, userB: UserProfile): CompatibilityResult {
        var score = 65 // Base compatibility for verified age & serious intentions

        // Common interests (+5% per common interest, up to 20%)
        val commonInterests = userA.interests.intersect(userB.interests.toSet()).toList()
        score += (commonInterests.size * 5).coerceAtMost(20)

        // Matching relationship goal (+10%)
        val goalMatches = userA.relationshipGoal == userB.relationshipGoal
        if (goalMatches) score += 10

        // Common languages (+5%)
        val commonLanguages = userA.languages.intersect(userB.languages.toSet()).toList()
        if (commonLanguages.isNotEmpty()) score += 5

        score = score.coerceIn(50, 98)

        return CompatibilityResult(
            percentage = score,
            commonInterests = commonInterests,
            goalMatches = goalMatches,
            commonLanguages = commonLanguages
        )
    }

    companion object {
        val instance by lazy { WidadRepository() }
    }
}

data class CompatibilityResult(
    val percentage: Int,
    val commonInterests: List<String>,
    val goalMatches: Boolean,
    val commonLanguages: List<String>
)
